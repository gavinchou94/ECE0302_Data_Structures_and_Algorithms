#ifndef _LINKED_ITERATOR
#define _LINKED_ITERATOR

#include <memory>
#include <iterator>

template <typename ItemType>
class LinkedIterator
{
private:
  // we may later learn to build an iterator for any ADT we defined ourselves
public:
}; // end LinkedIterator

#endif