#include "bitarray.hpp"

BitArray::BitArray()
{
    // TODO
}

BitArray::BitArray(intmax_t size)
{
    // TODO
}

BitArray::BitArray(const std::string &value)
{
    // TODO
}

BitArray::~BitArray()
{
    // TODO
}

// TODO: other methods