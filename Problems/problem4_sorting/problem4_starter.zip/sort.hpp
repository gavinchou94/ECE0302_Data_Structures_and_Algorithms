#ifndef _SORT_HPP
#define _SORT_HPP

#include "list.hpp"

template <typename T>
void quick_sort(List<T> &list, int first, int last)
{
	// TODO, note the 1-index based list
}

template <typename T>
int partition(List<T> &list, int first, int last)
{
	// TODO, note the 1-index based list
	return 0;
}

#endif
